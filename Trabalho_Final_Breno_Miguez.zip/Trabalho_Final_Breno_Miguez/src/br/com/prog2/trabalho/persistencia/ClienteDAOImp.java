package br.com.prog2.trabalho.persistencia;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import br.com.prog2.trabalho.negocio.Cliente;
import java.time.LocalDate;
public class ClienteDAOImp implements ClienteDAO {
	@Override
	public String inserir(Cliente emp) {
		String sql = "insert into cliente(codcliente,nomecliente,rgcliente,enderecocliente,bairrocliente,cidadecliente,estadocliente,cepcliente,nascimentocliente) values(?,?,?,?,?,?,?,?,?)";
		Connection con = ConnectionFactory.getConnection();
		try{
			PreparedStatement pst = con.prepareStatement(sql);
			pst.setString(1, emp.getCodCliente());
			pst.setString(2, emp.getNomeCliente());
			pst.setString(3, emp.getRgCliente());
			pst.setString(4, emp.getEnderecoCliente());
			pst.setString(5, emp.getBairroCliente());
			pst.setString(6, emp.getCidadeCliente());
			pst.setString(7, emp.getEstadoCliente());
			pst.setString(8, emp.getCepCliente());
			pst.setObject(9, emp.getNascimentoCliente());
			int res = pst.executeUpdate();
			if(res > 0){
				return "Inserido com sucesso.";
			}
			else{
				return "Erro ao inserir.";
			}
			}
			catch(SQLException e){
				return e.getMessage();
			}
			finally {
			ConnectionFactory.close(con);
			}
	}
	@Override
	public String alterar(Cliente emp) {
		String sql = "update cliente set nomecliente=?,rgcliente=?,enderecocliente=?,bairrocliente=?,cidadecliente=?,estadocliente=?,cepcliente=?,nascimentocliente=? where codcliente=?";
		Connection con = ConnectionFactory.getConnection();
		try{
		PreparedStatement pst = con.prepareStatement(sql);
		pst.setString(1, emp.getNomeCliente());
		pst.setString(2, emp.getRgCliente());
		pst.setString(3, emp.getEnderecoCliente());
		pst.setString(4, emp.getBairroCliente());
		pst.setString(5, emp.getCidadeCliente());
		pst.setString(6, emp.getEstadoCliente());
		pst.setString(7, emp.getCepCliente());
		pst.setObject(8, emp.getNascimentoCliente());
		pst.setString(9, emp.getCodCliente());
		int res = pst.executeUpdate();
		if(res > 0){
		return "Alterado com sucesso.";
		}else{
		return "Erro ao alterar.";
		}
		}catch(SQLException e){
		return e.getMessage();
		}finally {
		ConnectionFactory.close(con);
		}
	}
	@Override
	public String excluir(Cliente cli) {
		String sql = "delete from cliente where codcliente=?";
		Connection con = ConnectionFactory.getConnection();
		try{
		PreparedStatement pst = con.prepareStatement(sql);
		pst.setString(1, cli.getCodCliente());
		int res = pst.executeUpdate();
		if(res > 0){
		return "Excluido com sucesso.";
		}else{
		return "Erro ao excluir.";
		}
		}catch(SQLException e){
		return e.getMessage();
		}finally {
		ConnectionFactory.close(con);
		}
	}
	@Override
	public List<Cliente> listarTodos() {
		String sql = "select * from cliente";
		Connection con = ConnectionFactory.getConnection();
		List<Cliente> lista = new ArrayList<>();
		try {
		PreparedStatement pst = con.prepareStatement(sql);
		ResultSet rs = pst.executeQuery();
		if (rs != null) {
		while (rs.next()) {
		Cliente emp = new Cliente();
		emp.setCodCliente(rs.getString(1));
		emp.setNomeCliente(rs.getString(2));
		emp.setRgCliente(rs.getString(3));
		emp.setEnderecoCliente(rs.getString(4));
		emp.setBairroCliente(rs.getString(5));
		emp.setCidadeCliente(rs.getString(6));
		emp.setEstadoCliente(rs.getString(7));
		emp.setCepCliente(rs.getString(8));
		emp.setNascimentoCliente(rs.getObject(9, LocalDate.class));
		lista.add(emp);
		}
		return lista;
		} else {
		return null;
		}
		} catch (SQLException e) {
		return null;
		} finally {
		ConnectionFactory.close(con);
		}
	}
	@Override
	public Cliente pesquisarPorCod(String codCliente) {
		String sql = "select * from cliente where codcliente=?";
		Connection con = ConnectionFactory.getConnection();
		try {
		PreparedStatement pst = con.prepareStatement(sql);
		pst.setString(1, codCliente);
		ResultSet rs = pst.executeQuery();
		if (rs.next()) {
		Cliente emp = new Cliente();
		emp.setCodCliente(rs.getString(1));
		emp.setNomeCliente(rs.getString(2));
		emp.setRgCliente(rs.getString(3));
		emp.setEnderecoCliente(rs.getString(4));
		emp.setBairroCliente(rs.getString(5));
		emp.setCidadeCliente(rs.getString(6));
		emp.setEstadoCliente(rs.getString(7));
		emp.setCepCliente(rs.getString(8));
		emp.setNascimentoCliente(rs.getObject(9, LocalDate.class));
		return emp;
		} else {
		return null;
		}
		} catch (SQLException e) {
		return null;
		} finally {
		ConnectionFactory.close(con);
		}
	}
}
