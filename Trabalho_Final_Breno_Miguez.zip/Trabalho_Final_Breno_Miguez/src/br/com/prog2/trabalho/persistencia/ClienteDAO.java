package br.com.prog2.trabalho.persistencia;
import java.util.List;
import br.com.prog2.trabalho.negocio.Cliente;
public interface ClienteDAO {
	public String inserir(Cliente emp);
	public String alterar(Cliente emp);
	public String excluir(Cliente emp);
	public List<Cliente> listarTodos();
	public Cliente pesquisarPorCod(String codCliente);
}
